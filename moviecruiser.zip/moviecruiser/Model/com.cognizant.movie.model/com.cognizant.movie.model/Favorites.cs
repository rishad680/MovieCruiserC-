﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.model {
    public class Favorites {
        private List<Movie> _movieList;
        private double _total;

        public Favorites() {

        }

        public Favorites(List<Movie> _movieList, double _total) {
            this._movieList = _movieList;
            this._total = _total;
        }

        public List<Movie> MovieList {
            get {
                return _movieList;
            }
            set {
                _movieList = value;
            }
        }

        public double Total {
            get {
                return _total;
            }
            set {
                _total = value;
            }
        }

        public override string ToString() {
            string movieInfo = string.Empty;
            foreach (Movie movieItem in this._movieList) {
                movieInfo = movieItem + movieItem.Title + "   " + movieItem.Active + "   "
                    + (double)movieItem.Budget;
            }
            return string.Format("{0,-15}\n{1,-15}", movieInfo, this._total);
        }
    }
}
