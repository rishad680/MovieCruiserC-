﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieCruiserConsole {
    class MovieCruiserConsoleTest {

        static void Main(string[] args) {
            int menu = 0;
            do {
                Console.WriteLine("1.Movies \n2.Favorites\n3.Exit");
                menu = int.Parse(Console.ReadLine());
                switch (menu) {
                    case 1:
                        MovieDaoCollectionImplTest movieDaoTest = new MovieDaoCollectionImplTest();
                        break;
                    case 2:
                        FavoriteDaoCollectionImplTest favtDaoTest = new FavoriteDaoCollectionImplTest();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
                Console.WriteLine("do you want to continue? press 1 or 2");
            }
            while (menu != 3);
        }
    }
}
