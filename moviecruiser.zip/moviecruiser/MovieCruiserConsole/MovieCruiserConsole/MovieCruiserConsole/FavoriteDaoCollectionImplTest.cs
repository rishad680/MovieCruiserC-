﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace MovieCruiserConsole {
    class FavoriteDaoCollectionImplTest {

       public FavoriteDaoCollectionImplTest()
        {
            testAddFavoritesItem();
            testRemoveFavorite();

        }

        public static void testAddFavoritesItem() {
            FavoritesDaoCollectionImpl favtDao = new FavoritesDaoCollectionImpl();
            favtDao.addFavorite(1, 105);
            favtDao.addFavorite(1, 102);
            favtDao.addFavorite(1, 103);
            try {
                Console.WriteLine("Favourites:");
                testGetAllFavorites();
            }
            catch(FavoritesEmptyException e) {
                Console.WriteLine(e);
            }
        }

        public static void testRemoveFavorite() {
            FavoritesDaoCollectionImpl favtDao = new FavoritesDaoCollectionImpl();
            favtDao.removeFavorite(1, 103);
            try {
                Console.WriteLine("Updated Favorites:");
                testGetAllFavorites();
            }
            catch (FavoritesEmptyException e) {
                Console.WriteLine(e);
            }
        }

        public static void testGetAllFavorites() {
            FavoritesDaoCollectionImpl favtDao = new FavoritesDaoCollectionImpl();
            Favorites favt = favtDao.getAllFavorites(1);
            Console.WriteLine();
            Console.WriteLine("Title               Active              Budget");
            for (int i = 0; i < favt.MovieList.Count; i++) {
                Console.WriteLine("{0,-20}{1,-20}{2}", favt.MovieList[i].Title,
                favt.MovieList[i].Active == true ? "Yes" : "No", (double)favt.MovieList[i].Budget);
            }
            Console.WriteLine("Total=" + favt.Total);
        }
    }
}
