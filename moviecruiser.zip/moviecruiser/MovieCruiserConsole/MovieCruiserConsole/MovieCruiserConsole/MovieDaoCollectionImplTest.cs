﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace MovieCruiserConsole {
    class MovieDaoCollectionImplTest {

        public MovieDaoCollectionImplTest() {
            testGetMovieListAdmin();
            testGetMovieListCustomer();
            testModifyMovie();
        }

        public static void testGetMovieListAdmin() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListAdmin();
            Console.WriteLine();
            Console.WriteLine("Movie List for Admin");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget", "Active", "Date of Launch", "Genre", "Has Teaser");
            foreach(Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testGetMovieListCustomer() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListCustomer();
            Console.WriteLine();
            Console.WriteLine("Movie List for Customer");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget", 
                "Active", "Date of Launch", "Genre", "Has Teaser");
            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testModifyMovie() {
            Movie movieList = new Movie(105, "Avatar", 100000000.00f, true,
            DateUtil.convertToDate("30/09/2019"), "Adventure", true);
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            movieDao.modifyMovie(movieList);
            testGetMovie();
        }

        public static void testGetMovie() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(105);
            Console.WriteLine();
            Console.WriteLine("Updated Movie");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}", "Title", "Budget",
                "Active", "Date of Launch", "Genre", "Has Teaser");
            Console.WriteLine(movie);
        }
    }
}
