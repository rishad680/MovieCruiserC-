﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.dao {
    public class FavoritesEmptyException:Exception {
        private string _msg;

        public FavoritesEmptyException() {

        }
    
        public FavoritesEmptyException(string _msg) {
            this._msg = _msg;
        }

        public override string ToString() {
            return string.Format("{0}", this._msg);
        }
    }
}
