﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;


namespace com.cognizant.movie.dao {
    public class FavoritesDaoCollectionImpl : IFavoritesDao {

        private static Dictionary<long, Favorites> _userFavorites;

        public FavoritesDaoCollectionImpl() {
            if (_userFavorites == null) {
                _userFavorites = new Dictionary<long, Favorites>();
            }
        }

        public void addFavorite(long userId, long favoriteId) {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(favoriteId);
            if(_userFavorites.ContainsKey(userId)) {
                _userFavorites[userId].MovieList.Add(movie);
            } else {
                Favorites newFavorite = new Favorites();
                List<Movie> movieList = new List<Movie>();
                movieList.Add(movie);
                newFavorite.MovieList = movieList;
                _userFavorites.Add(userId, newFavorite);
            }
        }

        public Favorites getAllFavorites(long userId) {
            Favorites userFavorites = new Favorites();
            bool chk = _userFavorites.TryGetValue(userId, out userFavorites);
            if(userFavorites == null || userFavorites.MovieList.Count == 0) {
                throw new FavoritesEmptyException("Favorites is empty");
            }
            if(chk) {
                List<Movie> movieList = userFavorites.MovieList;
                double total = 0;
                foreach(Movie movie in movieList) {
                    total += movie.Budget;
                }
                userFavorites.Total = total;
            }
            return userFavorites;
        }

        public void removeFavorite(long userId, long favoriteId) {
            List<Movie> movielist = _userFavorites[userId].MovieList;
            for(int i=0; i<movielist.Count; i++) {
                if(favoriteId == movielist[i].Id) {
                    movielist.RemoveAt(i);
                }
            }
        }
    }
}
